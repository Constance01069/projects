library(testthat)
library(sobolMDA)

test_check("sobolMDA")